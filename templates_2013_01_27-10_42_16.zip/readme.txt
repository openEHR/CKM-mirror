These are templates exported from the Clinical Knowledge Manager.
Export time: Sun Jan 27 10:42:16 GMT 2013