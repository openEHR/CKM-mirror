These are termsets exported from the Clinical Knowledge Manager.
Export time: Sun Jan 27 10:42:42 GMT 2013